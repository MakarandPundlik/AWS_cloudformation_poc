exports.handler = async() => {
    return{
        statusCode:200,
        data:'Hello World'
    }
}